#ifndef NAME_H
#define NAME_H

void echo(char *str);
int printpath();
void printstr(char *str,int i,int j,char *base);
int username(int n, char *base);
void printdir();

#endif // !NAME#def
