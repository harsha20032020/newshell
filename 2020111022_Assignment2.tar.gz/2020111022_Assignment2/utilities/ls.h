#ifndef LS_H
#define LS_H

void lscommand(char *commands[100], int len, char *path);
int flaggerfunc(char *tokens[100],int len);
void classicls(char *command);
void hiddenfilesls(char *command);
void detailedls(char *command,int flag);

#endif // !NAME#def
