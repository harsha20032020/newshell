#ifndef PROCESS_H
#define PROCESS_H

void background(char *command[100], int len);
void foreground(char *command[100], int len);
void child();
#endif // !NAME#def
